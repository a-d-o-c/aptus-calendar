# Aptus Calendar Website

A complete website for the Aptus Calendar system - a temporal operating system aligned with natural cycles.

## What's Included

### Pages
- **index.html** - Homepage explaining what Aptus is
- **calendar.html** - Live calendar showing today's date and focus
- **converter.html** - Date converter and birthday calculator
- **about.html** - About the system and philosophy
- **guide.html** - (To be created) Detailed guide for each month

### Assets
- **styles.css** - Main stylesheet
- **aptus.js** - Core JavaScript library for date calculations
- **wheel.png** - Aptus calendar wheel logo

## Features

### Date Converter
- Convert Gregorian dates to Aptus
- Convert Aptus dates to Gregorian
- **Birthday Calculator** - Find your Aptus birthday from Gregorian birthdate

### Live Calendar
- Shows current Aptus date
- Month focus and intent
- Week phase (Orient, Engage, Amplify, Integrate)
- Season indicator
- Auto-updates

## How to Use

1. Open `index.html` in a web browser
2. All pages work locally - no server required
3. To deploy: Upload all files to any web host

## Technical Notes

- Pure HTML/CSS/JavaScript - no dependencies
- Works offline once loaded
- Mobile responsive
- Southern Hemisphere default (anchored Sept 22)

## Customization

To add Northern Hemisphere support:
- Modify `aptus.js` anchor date to March 20
- Flip seasonal assignments in month data

## Next Steps

- Create detailed guide page with all 13 months
- Add print-ready calendar PDFs
- Add downloadable widget versions
- Optional: Add API for developers

---

**Aptus Calendar** - A temporal operating system aligned with natural cycles.
