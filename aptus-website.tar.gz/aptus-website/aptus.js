// Aptus Calendar Core Library
// Handles all date conversions and calendar logic

const APTUS_DATA = {
    // Southern Hemisphere anchor (default)
    anchor: {
        gregorian: new Date("2026-09-22"),
        hemisphere: "southern"
    },
    
    months: [
        {name: "Verna", focus: "Initiation", season: "Spring", seasonClass: "spring", start: 1, end: 28},
        {name: "Cresca", focus: "Growth", season: "Spring", seasonClass: "spring", start: 29, end: 56},
        {name: "Flora", focus: "Expression", season: "Spring", seasonClass: "spring", start: 57, end: 84},
        {name: "Solaris", focus: "Visibility", season: "Summer", seasonClass: "summer", start: 85, end: 112},
        {name: "Arden", focus: "Sustained Effort", season: "Summer", seasonClass: "summer", start: 113, end: 140},
        {name: "Messia", focus: "Harvest", season: "Summer", seasonClass: "summer", start: 141, end: 168},
        {name: "Axia", focus: "Turning Point", season: "Autumn", seasonClass: "autumn", start: 169, end: 196},
        {name: "Valla", focus: "Holding", season: "Autumn", seasonClass: "autumn", start: 197, end: 224},
        {name: "Lenia", focus: "Softening", season: "Autumn", seasonClass: "autumn", start: 225, end: 252},
        {name: "Umbra", focus: "Stillness", season: "Winter", seasonClass: "winter", start: 253, end: 280},
        {name: "Noctis", focus: "Insight", season: "Winter", seasonClass: "winter", start: 281, end: 308},
        {name: "Spira", focus: "Readiness", season: "Winter", seasonClass: "winter", start: 309, end: 336},
        {name: "Lumen", focus: "Integration", season: "Late Winter", seasonClass: "winter", start: 337, end: 364}
    ],
    
    weeks: [
        {name: "Orient", intent: "Set direction. Reduce noise. Choose 1-3 priorities. Clear the path."},
        {name: "Engage", intent: "Begin. Do the first real reps. Make it measurable. Momentum over perfection."},
        {name: "Amplify", intent: "Push output. Ship/produce. Add volume. Communicate. Apply pressure (cleanly)."},
        {name: "Integrate", intent: "Consolidate. Review. Repair. Simplify. Prepare the next cycle."}
    ],
    
    intents: {
        "Verna": "Start small, start real. Choose a single seed project and begin. Prioritise habit formation and clean routines.",
        "Cresca": "Add volume (not chaos). Strengthen fundamentals. Build capacity and resilience.",
        "Flora": "Express and share. Create visibility for what you are building. Celebrate small wins; refine your voice.",
        "Solaris": "Make it public. Do the high-energy work in daylight. Create and connect; avoid burnout by scheduling recovery.",
        "Arden": "Sustained effort: consistency beats intensity. Commit to repetition. Protect deep-work blocks.",
        "Messia": "Harvest what is ready. Ship, deliver, invoice, close. Extract lessons and capture results.",
        "Axia": "Turn the wheel: choose what continues vs. ends. Prune ruthlessly. Re-orient toward the coming contraction.",
        "Valla": "Hold the line. Stabilise finances, home, systems. Maintain health and sleep; avoid over-expansion.",
        "Lenia": "Soften. Reduce load. Repair relationships and body. Simplify and slow transitions.",
        "Umbra": "Stillness and recovery. Minimalism: fewer inputs. Long-form thinking; restore reserves.",
        "Noctis": "Insight: review the year. Name patterns; journal; reflect. Refine principles and boundaries.",
        "Spira": "Readiness: prepare tools and plans. Train quietly. Set the stage for spring re-entry.",
        "Lumen": "Integration: unify what you learned. Close open loops. Design the spring plan; keep it light and executable."
    }
};

/**
 * Convert a Gregorian date to Aptus date
 * @param {Date} gregorianDate - JavaScript Date object
 * @param {string} hemisphere - "southern" or "northern"
 * @returns {Object} Aptus date info
 */
function getAptusDate(gregorianDate, hemisphere = "southern") {
    const anchor = APTUS_DATA.anchor.gregorian;
    const daysSinceAnchor = Math.floor((gregorianDate - anchor) / (1000 * 60 * 60 * 24));
    
    let naturalDay, naturalYear;
    
    // Handle dates before the anchor
    if (daysSinceAnchor < 0) {
        const daysBeforeAnchor = Math.abs(daysSinceAnchor);
        naturalYear = 12025;
        naturalDay = 365 - daysBeforeAnchor + 1;
        
        while (naturalDay <= 0) {
            naturalYear--;
            naturalDay += 365;
        }
    } 
    // Handle dates after day 365
    else if (daysSinceAnchor >= 365) {
        const yearsPassed = Math.floor(daysSinceAnchor / 365);
        naturalYear = 12026 + yearsPassed;
        naturalDay = (daysSinceAnchor % 365) + 1;
        if (naturalDay > 365) {
            naturalYear++;
            naturalDay = 1;
        }
    } 
    // Current anchor year
    else {
        naturalYear = 12026;
        naturalDay = daysSinceAnchor + 1;
    }

    // Handle Lacuna (day 365)
    if (naturalDay === 365) {
        return {
            day: "Lacuna",
            month: null,
            monthData: {
                name: "Lacuna",
                focus: "Threshold",
                season: "Transition",
                seasonClass: "spring"
            },
            weekNumber: 0,
            weekData: {
                name: "Reflect",
                intent: "Use this day for reset, review, and intention-setting."
            },
            year: naturalYear,
            hemisphere: hemisphere
        };
    }

    // Find the month
    const monthData = APTUS_DATA.months.find(m => 
        naturalDay >= m.start && naturalDay <= m.end
    );

    if (!monthData) {
        return null;
    }

    const dayInMonth = naturalDay - monthData.start + 1;
    const weekNumber = Math.ceil(dayInMonth / 7);
    const weekData = APTUS_DATA.weeks[weekNumber - 1];

    return {
        day: dayInMonth,
        month: monthData.name,
        monthData: monthData,
        weekNumber: weekNumber,
        weekData: weekData,
        year: naturalYear,
        hemisphere: hemisphere,
        intent: APTUS_DATA.intents[monthData.name]
    };
}

/**
 * Convert an Aptus date to Gregorian
 * @param {string} month - Month name (e.g., "Verna")
 * @param {number} day - Day of month (1-28)
 * @param {number} year - Natural Year (e.g., 12026)
 * @returns {Date} Gregorian date
 */
function aptusToGregorian(month, day, year) {
    const monthData = APTUS_DATA.months.find(m => m.name === month);
    if (!monthData) return null;
    
    const dayOfYear = monthData.start + day - 1;
    const yearsSinceAnchor = year - 12026;
    const totalDays = (yearsSinceAnchor * 365) + dayOfYear - 1;
    
    const anchor = APTUS_DATA.anchor.gregorian;
    const gregorianDate = new Date(anchor);
    gregorianDate.setDate(gregorianDate.getDate() + totalDays);
    
    return gregorianDate;
}

/**
 * Get Aptus birthday from Gregorian birthday
 * @param {Date} gregorianBirthday - Birthday in Gregorian calendar
 * @returns {Object} Aptus birthday info
 */
function getAptusBirthday(gregorianBirthday) {
    return getAptusDate(gregorianBirthday);
}

/**
 * Format Aptus date as string
 * @param {Object} aptusInfo - Result from getAptusDate
 * @returns {string} Formatted date string
 */
function formatAptusDate(aptusInfo) {
    if (aptusInfo.day === "Lacuna") {
        return `Lacuna, ${aptusInfo.year} NE`;
    }
    return `${aptusInfo.month} ${aptusInfo.day}, ${aptusInfo.year} NE`;
}

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        getAptusDate,
        aptusToGregorian,
        getAptusBirthday,
        formatAptusDate,
        APTUS_DATA
    };
}